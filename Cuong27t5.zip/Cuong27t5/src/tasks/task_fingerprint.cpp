// =====================================================
// task_fingerprint.cpp
// Task xử lý cảm biến vân tay AS608/R305
// =====================================================

#include <Arduino.h>
#include <Adafruit_Fingerprint.h>
#include "core/globals.h"
#include "core/buzzer.h"
#include "core/led.h"
#include "core/system_bits.h"

#define FINGER_RX 16
#define FINGER_TX 17

HardwareSerial mySerial(2);
Adafruit_Fingerprint finger = Adafruit_Fingerprint(&mySerial);

void setupFingerprintSensor() {
	mySerial.begin(57600, SERIAL_8N1, FINGER_RX, FINGER_TX);
	finger.begin(57600);
	if (finger.verifyPassword()) {
		Serial.println("FINGERPRINT SENSOR OK");
		fingerReady = true;
	} else {
		Serial.println("FINGERPRINT SENSOR FAIL");
		fingerReady = false;
	}
}
int checkFingerprint()
{
    uint8_t p = finger.getImage();

    if (p == FINGERPRINT_NOFINGER) {
        return -1; // chưa có ngón tay
    }

    if (p != FINGERPRINT_OK) {
        Serial.print("FINGER IMAGE ERROR: ");
        Serial.println(p);
        return 0;
    }

    p = finger.image2Tz();

    if (p != FINGERPRINT_OK) {
        Serial.print("FINGER CONVERT ERROR: ");
        Serial.println(p);
        return 0;
    }

    p = finger.fingerSearch();

    if (p == FINGERPRINT_OK) {
        Serial.print("FINGER MATCH ID: ");
        Serial.println(finger.fingerID);

        Serial.print("CONFIDENCE: ");
        Serial.println(finger.confidence);

        return finger.fingerID; // đúng vân tay
    }

    if (p == FINGERPRINT_NOTFOUND) {
        Serial.println("FINGER NOT FOUND");
        return 0; // có đặt tay nhưng không đúng
    }

    Serial.print("FINGER SEARCH ERROR: ");
    Serial.println(p);

    return 0;
}

void taskFingerprint(void *pv)
{
    setupFingerprintSensor();

    while (1)
    {
        if (!fingerReady)
        {
            vTaskDelay(pdMS_TO_TICKS(500));
            continue;
        }

        if (!rfidAuthenticated)
        {
            vTaskDelay(pdMS_TO_TICKS(100));
            continue;
        }

        int id = checkFingerprint();

        if (id > 0)
        {
            fingerAuthenticated = true;

            xEventGroupSetBits(systemEvents, BIT_FINGER_OK);

            Serial.print("FINGERPRINT OK, ID: ");
            Serial.println(id);

            lcdLine1 = "FINGER OK";
            lcdLine2 = "ENTER PASS";
            lcdMessageTime = millis();

            buzzerBeep(2000, 100);
            ledPulse(LED_MODE_BLUE, 300);
        }
        else if (id == 0)
        {
            Serial.println("FINGERPRINT FAIL");

            lcdLine1 = "FINGER FAIL";
            lcdLine2 = "TRY AGAIN";
            lcdMessageTime = millis();

            buzzerBeep(1000, 300);
            ledPulse(LED_MODE_RED, 500);
        }

        vTaskDelay(pdMS_TO_TICKS(30));
    }
}
